#ifndef ERROR_H_
#define ERROR_H_

#include <string>

void printErrorAndDie(std::string message) __attribute__ ((noreturn));

#endif
