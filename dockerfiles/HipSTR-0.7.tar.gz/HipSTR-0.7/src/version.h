#ifndef VERSION_H_
#define VERSION_H_

#include <string>

extern const std::string VERSION;

#endif
