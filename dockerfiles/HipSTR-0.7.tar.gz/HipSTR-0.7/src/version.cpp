#include "version.h"
const std::string VERSION = "v0.7";
