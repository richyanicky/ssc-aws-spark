./read_vcf_alleles_test input/chr1_regions.bed input/1kg.chr1.imputed.vcf.gz
./read_vcf_alleles_test input/chr1_regions_v2.bed input/1kg.chr1.imputed.vcf.gz

./read_vcf_priors_test input/chr1_regions.bed input/1kg.chr1.imputed.vcf.gz
./read_vcf_priors_test input/chr1_regions_v2.bed input/1kg.chr1.imputed.vcf.gz
