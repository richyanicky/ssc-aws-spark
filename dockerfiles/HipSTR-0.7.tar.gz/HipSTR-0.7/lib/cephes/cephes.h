#ifndef CEPHES_H
#define CEPHES_H

#ifdef __cplusplus
extern "C" {
#endif

  extern double bdtr ( int k, int n, double p ); 

#ifdef __cplusplus
}
#endif

#endif
